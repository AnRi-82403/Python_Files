def find_maximum(num):

    # فرض میکنیم که اولین عدد بزرگترین عدد است
    max_number = num[0]

    # پیمایش در لیست با استفاده از حلقه for
    for number in num:
        if number > max_number:
            max_number = number # به روز رسانی بزرگترین عدد

    return max_number

# مثال استفاده از تابع
numbers_list = [3,5,1,8,2,10,6]
print(find_maximum(numbers_list))