number_input = input("Enter a number: ") # دریافت ورودی از کاربر

number_str = str(number_input) # تبدیل ورودی به رشته

# بررسی پالیندروم بودن
is_palindrome = True # فرض اولیه این است که عدد پالیندروم است
length = len(number_str)

# مقایسه از ابتدا و انتها
for i in range(length // 2):
    if number_str[i] != number_str[length - i - 1]:
        is_palindrome = False # اگر یک جفت برابر پیدا نشود، عدد پالیندروم نیست
        break

# نمایش نتیجه
if is_palindrome:
    print("The number is palindrome")
else:
    print("The number is not palindrome")