n = int(input("Enter a number: ")) # دریافت ورودی از کاربر

# بررسی اینکه n عدد غیرمنفی باشد
if n < 0:
    print("The input must be positive")
else:
    # اگر n برابر با 0 یا 1 باید، مستقیما نتیجه را نمایش می دهیم
    if n == 0:
        fibonacci_n = 0
    elif n == 1:
        fibonacci_n = 1
    else:
        # متغیرها برای نگهداری دو عدد قبلی فیبوناچی
        a, b = 0, 1
        fibonacci_n = 0

        # محاسبه n امین عدد فیبوناچی
        for i in range(2, n+1):
            fibonacci_n = a + b # عدد فعلی برابر با مجموع دو عدد قبلی
            a = b # به روزرسانی a به b
            b = fibonacci_n # به روزرسانی b به عدد فعلی

    print(fibonacci_n)