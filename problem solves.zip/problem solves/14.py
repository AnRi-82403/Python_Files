# دریافت ورودی از کاربر
user_input = input("Please enter a list of numbers (separated by space): ")

# تبدیل ورودی به لیست
elements = user_input.split()

# ایجاد دیکشنری برای شمارش تکرارها
count_dic = {}

# شمارش تکرار هر عنصر
for element in elements:
    if element in count_dic:
        count_dic[element] += 1 # اگر عنصر وجود دارد، شمارش را یکی افزایش بده
    else:
        count_dic[element] = 1 # اگر عنصر وجود ندارد، آن را به دیکشنری اضافه کن و مقدار را 1 قرار بده

# نمایش نتایج
print("Count of each element: ")
for key, value in count_dic.items():
    print(f"{key}: {value}")