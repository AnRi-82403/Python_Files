# دریافت ابعاد ماتریس از کاربر
r = int(input("Enter a number: "))
c = int(input("Enter a number: "))

# ایجاد ماترسی خالی
matrix = []

# دریافت مقادیر ماتریس از کاربر
for i in range(r):
    row = [] # ایجاد یک ردیف خالی
    for j in range(c):
        value = int(input(f"Enter the value for element [{i+1}][{j+1}]: ")) # دریافت مقدار هر عنصر
        row.append(value) # افزودن مقدار به ردیف
    matrix.append(row) # افزودن ردیف به ماتریس

# محاسبه مجموع تمامی اعداد موجود در ماتریس
total = 0

for i in range(r):
    for j in range(c):
        total += matrix[i][j] # افزودن هر عنصر به مجموع

# نمایش نتیجه
print(total)