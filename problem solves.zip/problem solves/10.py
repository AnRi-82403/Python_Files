numbers_input = input("Enter a list of integer numbers with space: ") # دریافت ورودی از کاربر

# تبدیل ورودی به عدد صحیح
numbers = []
for num in numbers_input.split():
    numbers.append(int(num))

# الگوریتم مرتب سازی حبابی
n = len(numbers)
i = 0

while i < n:
    j = 0
    while j < n - i - 1:
        if numbers[j] > numbers[j + 1]:
            # تعویض مقادیر
            temp = numbers[j]
            numbers[j] = numbers[j + 1]
            numbers[j + 1] = temp
        j += 1
    i += 1

print(numbers) # نمایش لیست مرتب شده