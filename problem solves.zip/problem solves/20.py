# دریافت لیست از کاربر
input_list = input("Please enter the list of elements separated by spaces: ")

# تبدیل رشته ورودی به لیست
elements = input_list.split()

# ایجاد یک دیکشنری برای شمارش تکرار عناصر
count_dict = {}

# شمارش تکرار هر عنصر در لیست
for element in elements:
    if element in count_dict:
        count_dict[element] += 1 # افزایش شمارش عنصر
    else:
        count_dict[element] = 1 # اولین بار است که عنصر دیده میشود

# ایجاد لیستی برای گروه بندی عناصر بر اساس تعداد تکرار
grouped_elements = []

# گروه بندی عناصر بر اساس تعداد تکرار
for key in count_dict:
    frequency = count_dict[key]
    # ایجاد یک زیرلیست برای عناصر با تعداد تکرار مشابه
    while len(grouped_elements) <= frequency:
        grouped_elements.append([])
    grouped_elements[frequency].append(key)

# نمایش نتایج
for i in range(len(grouped_elements)):
    if len(grouped_elements[i]) > 0:
        print(f"Elements repeated {i} times: {grouped_elements[i]}")