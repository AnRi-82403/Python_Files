# دریافت ورودی از کاربر برای لیست اول
user_input1 = input("Please enter the first list (separated by space): ")
list1 = user_input1.split()

# دریافت ورودی برای لیست دوم
user_input2 = input("Please enter the second list (separated by space): ")
list2 = user_input2.split()

# ایجاد یک لیست خالی برای عناصر مشترک
common_elements = []

# بررسی هر عنصر در لیست اول
for element in list1:
    # اگر عنصر در لیست دوم وجود داشت، آن را به لیست مشترک اضافه کن
    if element in list2:
        common_elements.append(element)

# نمایش عناصر مشترک
print("Common elements between the two lists:")
for element in common_elements:
    print(element, end=" ")