# دریافت دو رشته ورودی از کاربر
string1 = input("Please enter the first string: ")
string2 = input("Please enter the first string: ")

# حذف فضاهای اضافی و تبدیل به حروف کوچک
string1 = string1.replace(" ","").lower()
string2 = string2.replace(" ","").lower()

# بررسی طول رشته ها
if len(string1) != len(string2):
    print("These two strings are not anagrams")
else:
    # ایجاد لیست برای شمارش حروف
    count = [0] * 26 # فرض بر اینکه حروف ها کوچک هستند

    # شمارش حروف در رشته اول
    for char in string1:
        index = ord(char) - ord('a') # تبدیل حرف به اندیس
        count[index] += 1 # افزایش شمارش به حرف

    # کاهش شمارش حروف با استفاده از رشته دوم
    for char in string2:
        index = ord(char) - ord('a') # تبدیل حرف به اندیس
        count[index] -= 1 # کاهش شمارش حرف

    # بررسی اینکه آیا تمام شمارش ها صفر هستند
    is_anagram = True
    for i in range(26):
        if count[i] != 0:
            is_anagram = False
            break
    if is_anagram:
        print("These two strings are anagrams")
    else:
        print("These two strings are not anagrams")