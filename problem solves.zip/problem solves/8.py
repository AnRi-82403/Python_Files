def is_prime(n): # تابع بررسی اول بودن عدد
    if n <= 1:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

number = int(input("Enter a number: ")) # دریافت عدد از کاربر

# چاپ اعداد اول کوچکتر از number
for num in range(2, number):
    if is_prime(num):
        print(num, end=" ")