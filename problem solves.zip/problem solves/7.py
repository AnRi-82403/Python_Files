num = int(input("Enter a number: ")) # گرفتن تعداد ردیف از کاربر

for i in range(1,num+1): # حلقه برای چاپ مثلث
    print("*" * i) # چاپ ستاره ها