sentence = input("Enter a sentence: ") # دریافت جمله از کاربر

words = sentence.split() # تقسیم جمله به کلمات

# متغیر برای نگهداری طولانی ترین کلمه و طول آن
longest_word = ""
max_length = 0

# پیمایش در لیست کلمات
i = 0
while i < len(words):
    # بررسی طول کلمه فعلی
    if len(words[i]) > max_length:
        longest_word = words[i] # به روزرسانی طولانی ترین کلمه
        max_length = len(words[i]) # به روزرسانی طول
    i += 1 # افزایش شمارنده

print(longest_word) # نمایش نتیجه