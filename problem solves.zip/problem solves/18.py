# دریافت لیست نام ها از کاربر
names_input = input("Please enter names separated by commas: ")
names_list = names_input.split(",")

# دریافت لیست نمرات از کاربر
grades_input = input("Please enter grades separated by commas: ")
grades_list = grades_input.split(",")

# ایجاد یک دیکشنری خالی برای ذخیره نام ها و نمرات
grades_dict = {}

# بررسی و اضافه کردن نام ها و نمرات به دیکشنری
for i in range(len(names_list)):
    # حذف فضای اضافی از نام ها و نمرات
    name = names_list[i].strip()
    grade = grades_list[i].strip()

    # اضافه کردن نام و نمره به دیکشنری
    grades_dict[name] = grade

# نمایش دیکشنری نهایی
print(grades_dict)