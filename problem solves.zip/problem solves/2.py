import random

# تولید یک عدد تصادفی بین 1 تا 50
random_num = random.randint(1,50)

while True:

    #دریافت ورودی از کاربر
    guess = int(input("Your guess:"))
    
    # بررسی اینکه حدس کاربر برابر با عدد تصادفی است یا خیر
    if guess < 1 or guess > 50:
        print("Please enter a number between 1 and 50.")
        continue

    if guess < random_num:
        print("The guessed number is smaller.")
    elif guess > random_num:
        print("The guessed number is bigger.")
    else :
        print("You have guessed the right number.")
        break