# تعریف اولیه لیست با عناصر تکراری
original_list = [1, 2, 2, 3, 4, 4, 5, 1, 6, 3]

# ایجاد یک لیست خالی برای ذخیره عناصر یکتا
unique_list = []

# بررسی هر عنصر در لیست اصلی
for item in original_list:
    # اگر در لست یکتا وجود ندارد، آن را اضافه کن
    if item not in unique_list:
        unique_list.append(item)

# نمایش لیست یکتا
print(unique_list)