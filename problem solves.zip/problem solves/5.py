num = int(input("Enter a number: ")) # دریافت ورودی از کاربر

# بررسی اینکه عدد منفی نباشد
if num < 0:
    print("Factorial isn't defined for negative numbers.")
else:
    fact = 1
    count = 1

    # محاسبه فاکتوریل با استفاده از حلقه while
    while count <= num:
        fact *= count # ضرب کردن عدد فعلی در فاکتوریل
        count += 1 # افزایش شمارنده

    print(fact)