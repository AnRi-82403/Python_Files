# دریافت ورودی از کاربر
user_input = input("Please enter the dictionary in key:value format (separated by commas): ")

# تقسیم ورودی به جفت های کلید و مقدار
pairs = user_input.split(",")

# ایجاد یک دیکشنری خالی برای دیکشنری معوس شده
reversed_dict = {}

# بررسی هر جفت کلید و مقدار
for pair in pairs:
    key_value = pair.split(":")
    if len(key_value) == 2:
        key = key_value[0].strip()
        value = key_value[1].strip()
        reversed_dict[value] = key

# نمایش دیکشنری معکوس شده
print("Reversed dictionary:")
for value, key in reversed_dict.items():
    print(f"{value}: {key}")