def sum_of_even(num):
    sum=0
    for i in range (1,num+1):
        if i%2 == 0 :
            sum += i
    return sum

print(sum_of_even(100))