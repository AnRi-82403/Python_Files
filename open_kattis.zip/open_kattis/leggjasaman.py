m=int(input())
n=int(input())
if 2<=m<=1000 and 2<=n<=1000:
    sum=m+n
    print(sum)
else:
    print("Enter the correct number")