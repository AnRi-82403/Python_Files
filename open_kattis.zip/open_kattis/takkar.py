a=int(input())
b=int(input())
if 0<=a<=10**9 and 0<=b<=10**9:
    if a>b:
        print("MAGA!")
    elif a<b:
        print("FAKE NEWS!")
    elif a==b:
        print("WORLD WAR 3!")
else:
    print("Enter the correct number")