w=str(input())
print(w[0])