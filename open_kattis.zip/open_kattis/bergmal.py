word=str(input())
if 1<=len(word)<=1000:
    print(word)