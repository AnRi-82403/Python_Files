n=int(input())
m=int(input())
if 1<=n and m<=10**6:
    r=n%m
    print(r)
else:
    print("Enter the correct number")