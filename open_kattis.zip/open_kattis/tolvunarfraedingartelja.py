n=int(input())
if 1<=n<=10**9:
    sub=n-1
    print(sub)
else:
    print("Enter the correct number")