n=int(input())
k=int(input())
if 0<=n<=2*(10**9) and 1<=k<=10**3:
    y=n//k
    print(2022+y)
else:
    print("Enter the correct number")