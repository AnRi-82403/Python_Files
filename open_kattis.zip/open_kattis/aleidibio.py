a=int(input())
b=int(input())
c=int(input())
if 1<=a<=100 and 1<=b<=100 and 720<=c<=1439:
    result=c-(a+b)
    print(result)
else:
    print("Enter the correct number")