n=int(input())
if 1<=n and n<=1000000:
    if n%10==0:
        print("Jebb")
    else:
        print("Neibb")
else:
    print("Enter the correct number")