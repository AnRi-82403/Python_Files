name=str(input())
print(f"Kvedja, \n {name}")