words=input()
char="u"
count=0
for word in words:
    if word==char:
        count+=1
print(count)