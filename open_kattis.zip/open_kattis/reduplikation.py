s=str(input())
n=int(input())
if 2<=len(s)<=10 and 1<=n<=9:
    print(s*n)