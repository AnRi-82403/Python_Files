DNA=str(input())
if 3<=len(DNA)<=1000:
    if "COV" in DNA:
        print("Veikur!")
    else:
        print("Ekki veikur!")