n=int(input())
m=int(input())
if 0<=m<=n and m<=n<=10000:
    sub=n-m
    print(sub)
else:
    print("Enter the correct number")