n=int(input())
if 1<=n<=10**5:
    print(n/4)
else:
    print("Enter the correct number")