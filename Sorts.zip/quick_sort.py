def quick_sort(arr) :
    stack = [(0, len(arr) - 1)] # استک برای نگهداری محدوده های آرایه
    
    while stack :
        start, end = stack.pop() # برداشتن آخرین محدوده از استک

        if start >= end :
            continue

        pivot = arr[end] # انتخاب آخرین عنصر به عنوان محور
        
        p_index = start # ایندکس محور

        for i in range(start, end) :
            if arr[i] < pivot :
                arr[i], arr[p_index] = arr[p_index], arr[i] # جابجایی عناصر
                p_index += 1

        arr[p_index], arr[end] = arr[end], arr[p_index] # قرار دادن محور در موقعیت درست

        # افزودن محدوده های جدید به استک
        stack.append((start, p_index - 1))
        stack.append((p_index + 1, end))

    return arr

arr = [10, 7, 8, 9, 1, 5]
sorted_arr = quick_sort(arr)
print(sorted_arr)