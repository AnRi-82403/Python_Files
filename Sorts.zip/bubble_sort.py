def bubble_sort(arr) :
    n=len(arr)
    # پیمایش در طول عناصر آرایه
    for i in range(n) :
        # عنصر در حال حاضر در مکان خود قرار دارد i آخرین
        for j in range(0,n-i-1) :
            # n-i-1 پیمایش آرایه از 0 تا 
            # اگر عنصر پیداشده بزرگتر از عنصر بعدی باشد، تعویض میکنیم
            if arr[j]>arr[j+1] :
                arr[j],arr[j+1] = arr[j+1],arr[j]

arr=[64,34,25,12,22,11,90] # مثال استفاده
bubble_sort(arr)
print(arr)