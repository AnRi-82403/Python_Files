def insertion_sort(arr) :
    # پیمایش از 1 تا طول آرایه
    for i in range(1,len(arr)) :
        key=arr[i]
        j=i-1
        # که بزرگتر از کلید هستند، به یک موقعیت جلوتر از موقعیت کنونی شان list[0..i-1] انتقال عناصر 
        while j>=0 and key<arr[j] :
            arr[j+1]=arr[j]
            j-=1
        arr[j+1]=key

arr=[64,34,25,12,22,11,90] # مثال استفاده
insertion_sort(arr)
print(arr)