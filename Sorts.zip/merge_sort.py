def merge_sort(arr) :
    if len(arr) > 1 :
        # پیدا کردن وسط آرایه
        mid=len(arr)//2

        # تقسیم آرایه به دو قسمت
        L=arr[:mid]
        R=arr[mid:]

        # مرتب سازی نیمه اول
        merge_sort(L)

        # مرتب سازی نیمه دوم
        merge_sort(R)

        i=j=k=0

        # R[] و L[] کپی داده ها به آرایه های موقت 
        while i<len(L) and j<len(R) :
            if L[i]<R[j] :
                arr[k]=L[i]
                i+=1
            else :
                arr[k]=R[j]
                j+=1
            k+=1

        # بررسی اینکه آیا عنصری باقی مانده است
        while i<len(L) :
            arr[k]=L[i]
            i+=1
            j+=1

        while j<len(R) :
            arr[k]=R[j]
            j+=1
            i+=1

arr=[64,34,25,12,22,11,90]
merge_sort(arr)
print(arr)